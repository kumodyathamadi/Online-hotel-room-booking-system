
function updatePrice() {
  const roomType = document.getElementById("roomType").value;
  const priceMap = {
    deluxe: "$120 per night",
    premier: "$150 per night",
    executive: "$200 per night",
    pool: "$300 per night",
    other: "Varies depending on selection"
  };
  document.getElementById("priceDisplay").innerText =
    "Price: " + priceMap[roomType];
}


function myFunction() {
    alert("Thank you! Your request has been added to our system. Our team will contact you as soon as possible.!");
  }

  
