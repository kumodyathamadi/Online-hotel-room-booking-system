var myindex = 0;

function imgSlideshow() {
    var i;
    var x = document.getElementsByClassName("slideshow");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    myindex++;
    if (myindex > x.length) {
        myindex = 1;
    }
    x[myindex - 1].style.display = "block";
    setTimeout(imgSlideshow, 2000);
}

// Run slideshow only after the page has fully loaded
window.onload = function() {
    imgSlideshow();
};
