function responsebtn() {
    alert("Thank you! We’ve received your message and will respond within one business day.");
  }

  
  document.getElementById("signUpForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = this.name.value.trim();
    const phone = this.phone.value.trim();
    const address = this.address.value.trim();
    const email = this.email.value.trim();
    const password = this.password.value;

    if (name === "" || phone === "" || address === "" || email === "" || password === "") {
      alert("Please fill in all required fields.");
      return;
    }

    if (!/^\d{10}$/.test(phone)) {
      alert("Please enter a valid 10-digit phone number.");
      return;
    }

    if (password.length < 6) {
      alert("Password must be at least 6 characters.");
      return;
    }

    alert("Thank you for signing up! Your account has been created.");
    this.reset();
  });

  // Sign In Form Validation
  document.getElementById("signInForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const email = this.email.value.trim();
    const password = this.password.value;

    if (email === "" || password === "") {
      alert("Please fill in both email and password.");
      return;
    }

    alert("Sign In successful!");
    this.reset();
  });

  // Optional: Add toggle behavior between Sign In / Sign Up
  document.getElementById("signIn").onclick = () => {
    document.querySelector(".sign-up-container").style.display = "none";
    document.querySelector(".sign-in-container").style.display = "block";
  };

  document.getElementById("signUp").onclick = () => {
    document.querySelector(".sign-in-container").style.display = "none";
    document.querySelector(".sign-up-container").style.display = "block";
  };


function signup(){
  alert("You have registered successfully!");
  window.location.href = 'hommepg.html';
    this.reset();
}